main ()
{
  apt install sudo
  clear
  sudo apt update
  clear
  sudo apt upgrade -y
  clear
  sudo bash pack.mcmeta
  clear
  sudo apt install pufferpanel
  clear
  sudo apt install systemctl -y
  clear
  pufferpanel user add
  clear
  systemctl enable --now pufferpanel
  clear
  bash online
}

main