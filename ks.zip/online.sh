main ()
{
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  echo "PufferPanel Installation Completed By KS Gamer Installer Thanks For Using"
  bash online
}

main